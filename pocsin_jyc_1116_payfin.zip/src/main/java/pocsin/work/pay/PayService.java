package pocsin.work.pay;

import java.util.List;

public interface PayService {

	void insertPaySuccess(PayVO vo);

	
}
