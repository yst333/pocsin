package pocsin.work.pay;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;

public class PayDAOTests {
	
	
	private PayDAO payDAO;

	@Before
	public void setUp() throws Exception {
	    // MyBatis 설정을 로딩하여 SqlSessionFactoryBean을 생성
	    SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
	    ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
	    Resource[] resources = resolver.getResources("classpath:mybatis-config.xml");
	    factoryBean.setMapperLocations(resources);

	    // 실제 테스트할 때는 데이터베이스와 연결을 위한 DataSource 설정 등을 추가해야 합니다.
	    // 여기에서는 테스트 데이터베이스를 사용한다고 가정하고 넘어갑니다.

	    payDAO = new PayDAO();
	}

	@Test
	public void testGetPaySuccess() {
	    PayVO vo = new PayVO();
	    // vo에 필요한 데이터 설정

	    String imp_uid = "결제성공아이디"; // 실제 데이터베이스에 존재하는 결제 아이디

	    // getPaySuccess 메소드 호출
	    PayVO paylist = payDAO.getPaySuccess(vo, imp_uid);

	    // 조회된 결과가 null이 아닌지 확인
	    assertNotNull(paylist);

	    // 추가적으로 필요한 테스트 로직을 구현해야 합니다.
	}

}




