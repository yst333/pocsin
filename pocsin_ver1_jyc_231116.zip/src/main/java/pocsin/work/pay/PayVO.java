package pocsin.work.pay;

import java.util.Date;

import lombok.Data;

@Data
public class PayVO {
	int pno;
	int paynum;
	String pbuyer;
	String padress;
	String pname;
	int pprice;
	int pnum;
	int pamount;
	Date pdate;
	
}
