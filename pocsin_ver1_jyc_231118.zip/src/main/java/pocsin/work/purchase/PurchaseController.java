package pocsin.work.purchase;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/purchase/*")
@AllArgsConstructor
public class PurchaseController {
	
	private PurchaseService service;
	

	//글목록 조회
	@RequestMapping(value="/pay/paysuccess")
	public void list(Model model) {
		log.info("list 글목록 조회처리!");
		model.addAttribute("list", service.getList());
	}
	
	//@DateTimeFormat(pattern ="yyMMdd")
	
	
//	@RequestMapping(value="/pay/paysuccess")
//	public ModelAndView PaySuccessPage() {
//		return new ModelAndView("/pay/paysuccess");
//	}
	
	
	
	
	
	
	
	//글 상세조회
//	@GetMapping({"/get", "/modify"})
//	public void get(@RequestParam("import_id") String import_id, Model model) {
//		
//		log.info("/get 조회 처리");
//		PurchaseVO purchase = service.get(import_id);
//		model.addAttribute("notice", service.get(import_id));
//
//	}

	//글 상세조회
	@GetMapping({"/get", "/modify"})
	public void get(Model model) {
		
		PurchaseVO purchase = service.get();
		log.info("/get 조회 처리" + purchase);
		model.addAttribute("purchase", service.get());
		
	}
	
	

}
