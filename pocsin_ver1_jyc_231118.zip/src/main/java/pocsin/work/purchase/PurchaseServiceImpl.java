package pocsin.work.purchase;

import java.util.List;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
@Primary
public class PurchaseServiceImpl implements PurchaseService{
	
	private PurchaseMapper mapper;
	
	//글 목록 
	@Override
	public List<PurchaseVO> getList() {
		log.info("getList... 목록 리스트 정보!");
		return mapper.getList();
	}
	
	

	//글 상세 조회
//	@Override
//	public PurchaseVO get(String import_id) {
//		log.info("get 특정 공지글 내용을 조회!" + import_id);
//		return mapper.read(import_id);
//	}

	//글 상세 조회
	@Override
	public PurchaseVO get() {
		log.info("get 특정 공지글 내용을 조회!");
		return mapper.read();
	}

	


}
