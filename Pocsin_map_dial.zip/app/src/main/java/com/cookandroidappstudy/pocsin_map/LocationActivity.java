package com.cookandroidappstudy.pocsin_map;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;


import com.google.android.gms.maps.MapView;
import com.webviewlocation.googlemapsexample.R;

public class LocationActivity extends AppCompatActivity {



    View rootView;
    MapView mapView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);


        Button dialButton = findViewById(R.id.btnDial);



        dialButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 다이얼러 앱을 호출하여 전화 걸기 키패드를 띄웁니다.
                Intent intent = new Intent(Intent.ACTION_DIAL);
                startActivity(intent);

            }
        });


        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        // Fragment를 추가하는 소스를 코딩해 줍니다!
        if(savedInstanceState == null){
            MainFragment mainFragment = new MainFragment();
            // tag: 식별 명칭은 "main"으로 처리합니다.
            getSupportFragmentManager().beginTransaction().replace(R.id.mainFragment, mainFragment, "main").commit();
        }
    }
}
