package com.cookandroidappstudy.pocsin_map;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.webviewlocation.googlemapsexample.R;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {


    View rootView;
    MapView mapView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);

    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {

//        MapsInitializer.initialize(this.mapView());

        CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(new LatLng(37.521398,127.021593), 14);

        googleMap.animateCamera(cameraUpdate);

        LatLng seoulCityHall = new LatLng(37.521398,127.021593);
        googleMap.addMarker(new MarkerOptions().position(seoulCityHall).title("Location : 아로마티카"));
    }




}

