package pocsin.work.notice;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;



@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class NoticeMapperTests {
	
	@Setter(onMethod_ = @Autowired)
	private NoticeMapper mapper;

	@Test
	public void testGetList() {
		mapper.getList().forEach(noti -> log.info(noti));
	}
	
	@Test
	public void testInsert() {
		NoticeVO notice = new NoticeVO();
		notice.setAdmin("testadmin");
		notice.setTitle("testtit02");
		notice.setContent("testcon02");
		
		mapper.insert(notice);
		log.info(notice);
	}
	
	@Test
	public void testDelete(){
		log.info("delete gogo : " + mapper.delete(4L));
	}
	
	@Test
	public void testUpdate() {
		NoticeVO notice = new NoticeVO();
		notice.setNbno(1L);
		notice.setTitle("junittest");
		notice.setContent("junitcont");
		notice.setAdmin("junitadmin");
		
		int count = mapper.update(notice);
		log.info("update count :" + count);
	}

}
