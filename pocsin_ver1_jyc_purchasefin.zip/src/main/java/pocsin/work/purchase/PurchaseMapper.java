package pocsin.work.purchase;

import java.util.List;

public interface PurchaseMapper {

	public PurchaseVO read();

}
