package pocsin.work.purchase;

public interface PurchaseService {

		// get = read 상세보기
		public PurchaseVO get();

}
