package pocsin.work.pay;

public interface PayService {

	void insertPaySuccess(PayVO vo);

	
}
